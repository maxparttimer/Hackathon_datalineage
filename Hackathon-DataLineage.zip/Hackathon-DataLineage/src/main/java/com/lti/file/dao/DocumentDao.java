package com.lti.file.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.lti.file.entity.Document;
import com.lti.file.entity.DocumentVersion;

@Repository
public class DocumentDao {

	private final String INSERT_SQL = "insert into documents (FileName,FileSize,UpdatedBy,UpdatedOn)  values (?,?,?,?)";
	private final String INSERT_VERSION_SQL = "insert into documentversions (DocumentId,FileName,VersionNumber,UpdatedBy,UpdatedOn) SELECT ?,?,(select IFNULL(max(VersionNumber)+1 ,1)from data_lineage.documentversions where documentId =?),?,? FROM DUAL";
	private final String FETCH_SQL = "select DocumentId,fileName,updatedBy,updatedOn from documents";
	private final String FETCH_ALL_VERSIONS = "select VersionNumber,FileName,UpdatedBy,UpdatedOn,VersionId,DocumentId from documentversions where DocumentId=? order by VersionId";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public int create(String fileName, String fileSize, String userName) {
		KeyHolder holder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
				PreparedStatement ps = connection.prepareStatement(INSERT_SQL, Statement.RETURN_GENERATED_KEYS);
				ps.setString(1, fileName);
				ps.setString(2, fileSize);
				ps.setString(3, userName);
				ps.setDate(4, new Date(new java.util.Date().getTime()));
				return ps;
			}
		}, holder);

		int documentId = holder.getKey().intValue();
		return documentId;
	}

	public int createVersion(int documentId, String userName, String fileName) {
		KeyHolder holder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
				PreparedStatement ps = connection.prepareStatement(INSERT_VERSION_SQL, Statement.RETURN_GENERATED_KEYS);
				ps.setInt(1, documentId);
				ps.setString(2, fileName);
				ps.setInt(3, documentId);
				ps.setString(4, userName);
				ps.setDate(5, new Date(new java.util.Date().getTime()));
				return ps;
			}
		}, holder);

		int versionId = holder.getKey().intValue();
		return versionId;
	}

	public List findAllVersions(int documentId) {
		return jdbcTemplate.query(FETCH_ALL_VERSIONS, new Object[] { documentId }, new VersionMapper());
	}

	@SuppressWarnings("unchecked")
	public List findAll() {
		return jdbcTemplate.query(FETCH_SQL, new DocumentMapper());
	}

}

class DocumentMapper implements RowMapper {

	@Override
	public Document mapRow(ResultSet rs, int rowNum) throws SQLException {
		Document document = new Document();
		
		
		document.setDocumentID(rs.getInt("DocumentId"));
		document.setFileName(rs.getString("fileName"));
		document.setUpdatedBy(rs.getString("updatedBy"));
		document.setUpdatedOn(rs.getDate("updatedOn"));
		return document;
	}

}

class VersionMapper implements RowMapper {

	@Override
	public DocumentVersion mapRow(ResultSet rs, int rowNum) throws SQLException {
		DocumentVersion documentVersion = new DocumentVersion();
		
		documentVersion.setVersionID(rs.getInt("VersionId"));
		documentVersion.setVersionNumber(rs.getInt("VersionNumber"));
		
		documentVersion.setDocumentID(rs.getInt("DocumentId"));
		documentVersion.setFileName(rs.getString("fileName"));
		documentVersion.setUpdatedBy(rs.getString("updatedBy"));
		documentVersion.setUpdatedOn(rs.getDate("updatedOn"));
		return documentVersion;
	}
}