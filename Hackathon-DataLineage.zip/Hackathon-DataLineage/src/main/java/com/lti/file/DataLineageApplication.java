package com.lti.file;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.lti.file.property.FileStorageProperties;

@SpringBootApplication
@EnableConfigurationProperties({ FileStorageProperties.class })
public class DataLineageApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataLineageApplication.class, args);
	}
}
